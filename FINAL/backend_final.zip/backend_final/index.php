<html>
  <head>
    <title>Video Streaming Demonstration</title>
  </head>
  <body>
    <h1>Video Streaming Demonstration</h1>
    <img id="bg" src="{{ url_for('video_feed') }}">
  </body>
</html>