package com.example.new_cv24;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Paint;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import com.google.android.gms.maps.model.LatLng;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;
import java.util.Locale;


public class OnTheSpot extends AppCompatActivity {

    JSONObject jsonObject, Addr;
    String DateTime, longitude, latitude;
    TextView DATETIME, ADDR;
    Button callOut;
    long diff;
    Geocoder geocoder;
    Address geoAddr;
    public String address;
    double LATITUDE, LONGITUDE;
    LatLng HERE;

    private static String IP_ADDRESS = "cv24.dothome.co.kr";
    private static String TAG = "phptest";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.on_the_spot);

        //잠금화면이어도 화면 뜨게 설정
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);

        Intent intent = getIntent();
        String data = intent.getStringExtra("violence case info");
        JSONparse(data);


        /*long now = System.currentTimeMillis();
        Date mDate = new Date(now);
        SimpleDateFormat simpleDate = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
        String getTime = simpleDate.format(mDate);

        timeCalc(getTime);

        Toast.makeText(this, Long.toString(diff),Toast.LENGTH_SHORT).show();

        //'경과시간'이므로 수정필요
        DATETIME = (TextView) findViewById(R.id.elapsedTimeDetail);
        DATETIME.setText(Long.toString(diff));*/

        //일단 현재는 사건 발생 시간을 출력하기로 함.
        DATETIME = (TextView) findViewById(R.id.elapsedTimeDetail);
        DATETIME.setText(DateTime);

        //'자세히'를 누르면 위치 정보를 가지고 LocationMap 실행
        ADDR = (TextView) findViewById(R.id.locationDetail);
        ADDR.setPaintFlags(ADDR.getPaintFlags() | Paint.UNDERLINE_TEXT_FLAG);
        ADDR.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mapInfo(data);
            }
        });

        callOut = findViewById(R.id.callOut);
        callOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //String id = "44";  //사건 정보의 index (게시판 보면 알 수 있음)

                Toast.makeText(getApplicationContext(),"완료 버튼 누름",Toast.LENGTH_LONG);

                LATITUDE = Double.parseDouble(latitude);
                LONGITUDE = Double.parseDouble(longitude);

                HERE = new LatLng(LATITUDE, LONGITUDE);
                address = getCurrentAddress(HERE);

                //Toast.makeText(getApplicationContext(),address,Toast.LENGTH_LONG);

                InsertData task = new InsertData();
                //task.execute("http://" + IP_ADDRESS + "/insert.php", DateTime, latitude, longitude);
                task.execute("http://" + IP_ADDRESS + "/insert.php", DateTime, address);
                //Toast.makeText(getApplicationContext(),address,Toast.LENGTH_LONG);
            }
        });
    }

    //String jsonStr = "{ 'addr': {'lat': 37.50497683800223, 'long': 126.9391820120632}, 'DateTime' : '2021-01-25 16:35:31'}";
    /* UDP로 받은 데이터(JSON 구조의 String 타입)를 JSON 객체로 변환하여 내용추출하는 메소드 */
    public void JSONparse(String jsonStr) {
        try {
            jsonObject = new JSONObject(jsonStr);  //JSON string을 JSON 객체로 변경

            //situation = jsonObject.getString("situation");  //위험상황 변수 저장
            DateTime = jsonObject.getString("DateTime");  //사건 발생 일시 및 시간 변수 저장

            Addr = jsonObject.getJSONObject("addr");
            latitude = Addr.getString("lat");  //사건 발생 위치 위도 저장
            longitude = Addr.getString("long");  //사건 발생 위치 경도 저장

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void mapInfo(CharSequence message){
        Intent intent = new Intent(getApplicationContext(), LocationMap.class);
        intent.putExtra("location info", message);
        startActivity(intent);
    }

    public void timeCalc(String now){
        //e.g.) String now = "2021-02-18 23:38:29";
        //DateTime도 동일한 형태이다.

        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");

        try {
            Date situation = formatter.parse(DateTime);
            Date current = formatter.parse(now);

            diff = current.getTime() - situation.getTime();

            //Toast.makeText(this, Long.toString(current.getTime()),Toast.LENGTH_SHORT).show();
            
            //맞는 계산 아닌 듯.. 예제랑 형식이 다름
            //long diffDays = diff / (24 * 60 * 60 * 1000);

        } catch (ParseException e) {
            e.printStackTrace();
        }
    }

    class InsertData extends AsyncTask<String, Void, String>{
        ProgressDialog progressDialog;
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog = ProgressDialog.show(OnTheSpot.this,
                    "Please Wait", null, true, true);
        }
        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            progressDialog.dismiss();
            Log.d(TAG, "POST response  - " + result);
        }
        @Override
        protected String doInBackground(String... params) {
            String time = (String)params[1];
            String address = (String)params[2];
            /*String latitude = (String)params[2];
            String longitude = (String)params[3];*/
            String serverURL = (String)params[0];

            String postParameters = "time=" + time + "&address=" + address;
            try {
                URL url = new URL(serverURL);
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                httpURLConnection.setReadTimeout(5000);
                httpURLConnection.setConnectTimeout(5000);
                httpURLConnection.setRequestMethod("POST");
                httpURLConnection.connect();
                OutputStream outputStream = httpURLConnection.getOutputStream();
                outputStream.write(postParameters.getBytes("UTF-8"));
                outputStream.flush();
                outputStream.close();
                int responseStatusCode = httpURLConnection.getResponseCode();
                Log.d(TAG, "POST response code - " + responseStatusCode);
                InputStream inputStream;
                if(responseStatusCode == HttpURLConnection.HTTP_OK) {
                    inputStream = httpURLConnection.getInputStream();
                }
                else{
                    inputStream = httpURLConnection.getErrorStream();
                }
                InputStreamReader inputStreamReader = new InputStreamReader(inputStream, "UTF-8");
                BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
                StringBuilder sb = new StringBuilder();
                String line = null;
                while((line = bufferedReader.readLine()) != null){
                    sb.append(line);
                }
                bufferedReader.close();
                return sb.toString();
            } catch (Exception e) {
                Log.d(TAG, "InsertData: Error ", e);
                return new String("Error: " + e.getMessage());
            }
        }
    }

    /* 지오코더를 이용해서 GPS를 주소로 변환해주는 메소드 */
    public String getCurrentAddress(LatLng HERE) {
        geocoder = new Geocoder(this, Locale.getDefault());

        List<Address> addresses;

        //예외처리
        try {
            addresses = geocoder.getFromLocation(HERE.latitude, HERE.longitude, 1);
        } catch (IOException ioException) {
            //네트워크 문제
            Toast.makeText(this, "지오코더 서비스 사용불가", Toast.LENGTH_LONG).show();
            return "지오코더 서비스 사용불가";
        } catch (IllegalArgumentException illegalArgumentException) {
            Toast.makeText(this, "잘못된 GPS 좌표", Toast.LENGTH_LONG).show();
            return "잘못된 GPS 좌표";
        }

        if (addresses == null || addresses.size() == 0) {
            Toast.makeText(this, "주소 미발견", Toast.LENGTH_LONG).show();
            return "주소 미발견";
        }
        else {
            geoAddr = addresses.get(0);
            //Toast.makeText(this,geoAddr.getAddressLine(0),Toast.LENGTH_LONG);
            Log.d("getCurrentAddress",geoAddr.getAddressLine(0));
            return geoAddr.getAddressLine(0).toString();  //리턴값이 String
        }
    }
}